#include <iostream>
#include"matrix.h"
using namespace std;

int main()
{
     int num , scalar , choice;
     matrix mat1 , mat2;
while (true){
        cout<<"Enter first Matrix"<<endl;
  cin>>mat1;
  cout<<"Enter second Matrix"<<endl;
  cin>>mat2;

do{

  cout<<endl<<"First Matrix : "<<endl<<mat1<<endl<<"Second Matrix : "<<endl<<mat2<<endl;

  cout<<"1 - operator+   (matrix mat1, matrix mat2) "<<endl;
  cout<<"2 - operator-   (matrix mat1, matrix mat2) "<<endl;
  cout<<"3 - operator*   (matrix mat1, matrix mat2) "<<endl;
  cout<<"4 - operator+   (matrix mat1, int scalar) "<<endl;
  cout<<"5 - operator-   (matrix mat1, int scalar) "<<endl;
  cout<<"6 - operator*   (matrix mat1, int scalar) "<<endl;
  cout<<"7 - operator+=  (matrix& mat1, matrix mat2) "<<endl;
  cout<<"8 - operator-=  (matrix& mat1, matrix mat2) "<<endl;
  cout<<"9 - operator+=  (matrix& mat1, int scalar) "<<endl;
  cout<<"10- operator-=  (matrix& mat1, int scalar) "<<endl;
  cout<<"11-  operator++ (matrix& mat1) "<<endl;
  cout<<"12-  operator-- (matrix& mat1) "<<endl;
  cout<<"13- operator==  (matrix mat1, matrix mat2) "<<endl;
  cout<<"14- operator!=  (matrix mat1, matrix mat2) "<<endl;
  cout<<"15- isSquare    (matrix mat1) "<<endl;
  cout<<"16- isSymetric  (matrix mat1) "<<endl;
  cout<<"17- isIdentity  (matrix mat1) "<<endl;
  cout<<"18- transpose   (matrix mat1) "<<endl<<endl;
  cout<<"Select number: ";
  cin>>num;
  if(num==1){
   cout<< (mat1+mat2)<<endl;

  }
  else if (num==2){
   cout<< (mat1-mat2)<<endl;
  }
  else if (num==3){
   cout<< (mat1*mat2)<<endl;
  }
  else if (num==4){
   cout<<"Enter a scalar: ";
   cin>>scalar;
   cout<< mat1+scalar;
  }
  else if (num==5){
   cout<<"Enter a scalar: ";
   cin>>scalar;
   cout<< mat1-scalar;
  }
  else if (num==6){
   cout<<"Enter a scalar: ";
   cin>>scalar;
   cout<< mat1*scalar;
  }

  else if (num==7){

    cout<<(mat1+=mat2)<<endl;
  }
  else if (num==8){

     cout<<(mat1-=mat2)<<endl;
  }
  else if (num==9){
   cout<<"Enter a scalar: ";
   cin>>scalar;
   cout<<(mat1+=scalar)<<endl;
  }
  else if (num==10){
     cout<<"Enter a scalar: ";
     cin>>scalar;
     cout<<(mat1-=scalar)<<endl;
  }
  else if (num==11){
    cout<<++mat1;
  }
  else if (num==12){
    cout<<--mat1;
  }
  else if (num==13){
    (mat1==mat2);
  }
  else if (num==14){
    (mat1!=mat2);
  }
  else if (num==15){
   (isSquare(mat1));
  }
  else if (num==16){
    isSymetric(mat1);
  }
  else if (num==17){
   isIdentity(mat1);
  }
  else if (num==18){
  cout<< transpose(mat1);

  }

  cout<<endl<<"Press 1 to try again , press any other key to exit\n ";
  cin>>choice;

}while(choice==1);
break;
}
    return 0;
}
