#include "matrix.h"
#include<iostream>
#include<vector>
using namespace std;

matrix::matrix()
{

}

matrix::matrix (int row, int col, int num[],matrix&mat) //constructor creates 2D array
{
  mat.row = row;
mat.col = col;
 mat. data = new int* [row];

  for (int i = 0; i < row; i++)
    mat.data[i] = new int [col];

  for (int i = 0; i < row; i++)
    for (int j = 0; j < col; j++)
      mat.data[i][j] = num[i * col + j];

}

istream& operator>> (istream& in, matrix& mat){
cout<<"Enter row,col: ";
in >> mat.row >> mat.col; // Row and Column entered
cout<<endl;
cout<<"Enter a data:"<<endl;
int datax[mat.row*mat.col]; //Size needed by matrix
matrix(mat.row,mat.col,datax,mat);
 for(int i=0;i<mat.row;i++){
    for(int j=0;j<mat.col;j++){
        in>>mat.data[i][j];}}
       return in;}

ostream& operator<< (ostream& out, matrix mat) {
   for(int i = 0;i < mat.row;i++){
    for(int j = 0;j < mat.col;j++){
  out <<"  " <<mat.data[i][j] ; }
  out << endl; }
  return out; // out returned to continue (<<) usage
   }

matrix matrix :: operator + (matrix mat1)
{
matrix mat; // Creating new Matrix
int data1[mat1.row*mat1.col];
matrix(mat1.row,mat1.col,data1,mat);

if(mat1.row==row && mat1.col==col){ //Condition (addition in matrix must be between 2 same dimensions matrices)

for(int i=0;i<mat1.row;i++){
    for(int j=0;j<mat1.col;j++){
        mat.data[i][j]= data[i][j]+ mat1.data[i][j];}} // every element in 2 matrices is added in a third matrix
return mat;}
else{
    cout<<"Invalid"<<endl; // Addition can't occur with different dimensions
return mat1;}
    }

matrix matrix:: operator-(matrix mat1){

matrix mat; // matrix creation
int data1[mat1.row*mat1.col];
matrix(mat1.row,mat1.col,data1,mat);

if(mat1.row==row && mat1.col==col){ // same dimensions

for(int i=0;i<mat1.row;i++){
    for(int j=0;j<mat1.col;j++){
        mat.data[i][j]= mat1.data[i][j]- data[i][j];}}
return mat;}
else{
    cout<<"Invalid"<<endl; // subtraction can't occur with different dimensions
    return mat1;}
    }

//-------------------------------------------------------------
matrix matrix:: operator *  (matrix mat1){
 int sum;

matrix mat;
int data1[ row * mat1.col ];
matrix(mat1.row , mat1.col , data1 , mat);

if(mat1.row == col ){ // First column = second row

for(int i = 0;i < row;i++){
    for(int j = 0;j < col;j++){
            sum = 0; // Value added in each element in mat must be set to 0
            for(int k = 0;k < mat1.col;k++){
        sum = sum + mat1.data[i][k] * data[k][j]; }
        mat.data[i][j] = sum;
    }
}
return mat;
}
else
    cout<<"Invalid"<<endl;
}

matrix matrix:: operator+  (int scalar){
matrix mat4; // matrix creation
int data4[row*col];
matrix(row,col,data4,mat4);

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        mat4.data[i][j]= data[i][j]+scalar;}}
return mat4;
}

//-------------------------------------------------------------
matrix matrix:: operator-  (int scalar){
matrix mat4;// matrix creation
int data4[row*col];
matrix(row,col,data4,mat4);

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        mat4.data[i][j]= data[i][j]-scalar;}}
return mat4;
}

//-------------------------------------------------------------
matrix matrix:: operator*  (int scalar){
matrix mat4; // matrix creation
int data4[row*col];
matrix(row,col,data4,mat4);

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        mat4.data[i][j]= data[i][j]*scalar;}}
return mat4;
}


//-------------------------------------------------------------

matrix matrix:: operator+= (matrix& mat1){ // matrix reference to change the matrix itself
    if(mat1.row == row && mat1.col == col){ // must have same dimensions

for(int i=0;i<mat1.row;i++){
    for(int j=0;j<mat1.col;j++){
        mat1.data[i][j]= mat1.data[i][j]+ data[i][j];
        }}

return mat1; }
else cout<<"Invalid"<<endl;
return mat1;
}
//--------------------------------------------------------------
matrix matrix:: operator-= (matrix& mat1){
    if(mat1.row == row && mat1.col == col){// must have same dimensions
    for(int i=0;i<mat1.row;i++){
    for(int j=0;j<mat1.col;j++){
        mat1.data[i][j]= mat1.data[i][j]- data[i][j];
        }}
return mat1;}
else cout<<"Invalid"<<endl;
return mat1;
}

//--------------------------------------------------------------

matrix matrix:: operator+= ( int scalar){
 matrix mat4; // matrix creation
int data4[row*col];
matrix(row,col,data4,mat4);

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        mat4.data[i][j]= data[i][j]+scalar;}}
return mat4;
}

//--------------------------------------------------------------
matrix matrix:: operator-= ( int scalar){

matrix mat4;// matrix creation
int data4[row*col];
matrix(row,col,data4,mat4);

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        mat4.data[i][j]= data[i][j]-scalar;}}
return mat4;
}

//--------------------------------------------------------------

matrix  matrix:: operator++ (){
    matrix mat = * this; //matrix mat will have the class attributes (row , column , data)

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        data[i][j]= data[i][j]+1;}} //each element in matrix will be increased by 1

return mat;}

//--------------------------------------------------------------
matrix  matrix:: operator-- (){
    matrix mat = * this; //matrix mat will have the class attributes (row , column , data)

for(int i=0;i<row;i++){
    for(int j=0;j<col;j++){
        data[i][j]= data[i][j]-1;}} //each element in matrix will be subtracted by 1

return mat;
}

//---------------------------------------------------------------

bool matrix:: operator == (matrix mat1){

    int indicator = 0; // indicator = 0 means the matrices are equal , else = 1 --> not equal

if(mat1.row==row && mat1.col==col) // first indicator --> the dimensions are not equal
    {
       for(int i = 0;i < mat1.row;i++){
    for(int j = 0 ;j < mat1.col;j++) {
        if(mat1.data[i][j] != data[i][j]){
            indicator = 1;break;} // second indicator --> elements not equal
    }}
}
else indicator = 1;
if(indicator == 1) // indicator changes so matrices are not equal
    cout<<"Not Equal"<<endl;
else
cout<<"Equal"<<endl; // indicator is the same (0) so matrices are equal
}

//---------------------------------------------------------------
bool matrix::  operator != (matrix mat1){

    char indicator=0;
if(mat1.row == row && mat1.col == col)
    {
       for(int i = 0;i < mat1.row;i++){
    for(int j = 0;j < mat1.col;j++) {
        if(mat1.data[i][j] != data[i][j]){
            indicator = 1;break;}
    }}
}
else indicator = 1;
if(indicator == 1 )
cout<<"Not Equal"<<endl;
else
cout<<"Equal"<<endl;
}

//-------------------------------------------------------------
bool isSquare (matrix mat){
if(mat.row == mat.col) // dimensions equal?
    cout<<"Matrix is Square";
else
    cout<<"Matrix is not Square";

}
//--------------------------------------------------------------
void isSymetric (matrix mat){
    char indicator = 0;
if(mat.row != mat.col)// dimensions equal?
    indicator = 1; // first error --> indicator changes
 else{
for(int i = 0;i < mat.row ;i++){
    for(int j = 0;j < mat.col ;j++){
            if(i != j){
        if(mat.data[i][j] != mat.data[j][i] )
            indicator = 1; // second error --> indicator changes
        }
    }}}
    if (indicator == 0) //no change in indicator = symmetric
    cout<<"Symmetric"<<endl;
    else
    cout<<"Not Symmetric"<<endl; //change in indicator = not symmetric
}
//--------------------------------------------------------------
void isIdentity (matrix mat){
   char indicator=0;
if(mat.row == mat.col){
for (int i = 0 , j = 0 ; i < mat.row , j < mat.col  ;i++ , j++){
    if(mat.data[i][j] != 1){
    indicator = 1;break;}  // main diagonal = 1 ?
}
for(int i = 0; i < mat.row; i++){
    for(int j = 0; j < mat.row; j++){
        if(i != j ){
            if(mat.data[i][j] != 0) //other elements = 0 ?
                indicator = 1 ;
        }
    }}
}
else indicator = 1;
if(indicator==1)
cout<<"Not Identity"<<endl;

else
cout<<"Identity"<<endl;
}
//--------------------------------------------------------------
matrix  transpose(matrix mat){
    matrix trans;
    int data1[mat.row*mat.col];
    matrix(mat.col ,mat.row ,data1 ,trans);
for(int i = 0; i < mat.row; i++){
    for(int j = 0; j < mat.col; j++){
        trans.data[j][i]=mat.data[i][j]; //rows = columns , columns = rows
    }}
    return trans;
}
matrix::~matrix()
{
    //destructor
};

